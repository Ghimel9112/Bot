//here the event starts
module.exports = (client, error) => {
    console.log(String(error).red.dim);
}